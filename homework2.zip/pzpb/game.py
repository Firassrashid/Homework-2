import turtle

screen = turtle.Screen()
pen = turtle.Turtle()

# Draw shapes based on user input
while True:
  shape = input("Enter shape (square, circle, triangle): ")
  if shape == "square":
    for _ in range(4):
      pen.forward(100)
      pen.left(90)
  elif shape == "circle":
    pen.circle(50)
  elif shape == "triangle":
    for _ in range(3):
      pen.forward(100)
      pen.left(120)
  else:
    print("Invalid shape!")

screen.exitonclick()
