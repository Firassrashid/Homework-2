import socket

HOST = '127.0.0.2'  
PORT = 8989        

def connect_and_send(account, operation, amount=None):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.connect((HOST, PORT))
        data = f"{account},{operation}"
        if amount:
            data += f",{amount}"
        s.sendall(data.encode())
        response = s.recv(1024).decode()
        print(response)


def main():
    account = input("Enter account number: ")
    while True:
        operation = input("Enter operation (check, deposit, withdraw, exit): ")
        if operation == "exit":
            break
        if operation in ["deposit", "withdraw"]:
            amount = float(input("Enter amount: "))
        else:
            amount = None
        connect_and_send(account, operation, amount)


if __name__ == "__main__":
    main()
